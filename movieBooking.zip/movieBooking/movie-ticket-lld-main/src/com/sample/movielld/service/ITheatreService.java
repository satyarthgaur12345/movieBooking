package com.sample.movielld.service;

import com.sample.movielld.entities.Theatre;

public interface ITheatreService {

	Theatre addTheatre(Theatre theatre1);

}
