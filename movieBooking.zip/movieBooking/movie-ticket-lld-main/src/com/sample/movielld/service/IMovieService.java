package com.sample.movielld.service;

import com.sample.movielld.entities.Movie;

public interface IMovieService {

	Movie addMovie(Movie m1);


}
