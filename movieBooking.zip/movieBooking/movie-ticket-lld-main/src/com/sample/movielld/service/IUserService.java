package com.sample.movielld.service;

import com.sample.movielld.entities.User;

public interface IUserService {

	User addUser(User u1);

	User getUser(long i);

}
