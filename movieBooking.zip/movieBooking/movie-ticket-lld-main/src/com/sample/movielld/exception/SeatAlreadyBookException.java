package com.sample.movielld.exception;

public class SeatAlreadyBookException extends RuntimeException {

}
