package com.sample.movielld.enums;

public enum SeatStatus {
	VACANT,
	BOOKED
}
