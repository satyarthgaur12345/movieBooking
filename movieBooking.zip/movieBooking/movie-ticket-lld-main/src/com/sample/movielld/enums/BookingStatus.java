package com.sample.movielld.enums;

public enum BookingStatus {
	CREATED,
	PENDING_FOR_PAYMENT,
	PAYMENT_FAILED,
	COMPLETED
}
